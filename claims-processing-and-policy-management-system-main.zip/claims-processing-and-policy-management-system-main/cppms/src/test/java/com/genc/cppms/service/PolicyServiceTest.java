package com.genc.cppms.service;

import com.genc.cppms.enum_types.PolicyStatus;
import com.genc.cppms.enum_types.PolicyType;
import com.genc.cppms.model.Policy;
import com.genc.cppms.repository.PolicyRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PolicyServiceTest {

    @Mock
    private PolicyRepository policyRepository;

    @InjectMocks
    private PolicyService policyService;

    @Captor
    private ArgumentCaptor<Policy> policyCaptor;

    private Policy proposedHealthPolicy;

    @BeforeEach
    void setUp() {
        proposedHealthPolicy = new Policy();
        proposedHealthPolicy.setPolicyId(1);
        proposedHealthPolicy.setPolicyHolderName("Alex Johnson");
        proposedHealthPolicy.setPolicyType(PolicyType.HEALTH);
        proposedHealthPolicy.setSumInsured(250000d);
        proposedHealthPolicy.setPolicyStatus(PolicyStatus.PROPOSED);
    }

    @Test
    void createPolicyShouldInitializeDefaultValues() {
        Policy request = new Policy();
        request.setPolicyHolderName("Jamie Doe");
        request.setPolicyType(PolicyType.LIFE);
        request.setSumInsured(150000d);

        when(policyRepository.save(any(Policy.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Policy createdPolicy = policyService.createPolicy(request);

        assertEquals(PolicyStatus.PROPOSED, createdPolicy.getPolicyStatus());
        assertEquals(0.0d, createdPolicy.getPremiumAmount());
        assertNull(createdPolicy.getExpiryDate());
    }

    @Test
    void performUnderwritingShouldCalculatePremiumForEligiblePolicy() {
        when(policyRepository.findById(1)).thenReturn(Optional.of(proposedHealthPolicy));
        when(policyRepository.save(any(Policy.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Policy underwrittenPolicy = policyService.performUnderwriting(1);

        assertEquals(PolicyStatus.PROPOSED, underwrittenPolicy.getPolicyStatus());
        assertEquals(10000.00d, underwrittenPolicy.getPremiumAmount());
        assertNull(underwrittenPolicy.getExpiryDate());
    }

    @Test
    void performUnderwritingShouldCancelPolicyAboveThreshold() {
        proposedHealthPolicy.setSumInsured(600000d);
        when(policyRepository.findById(1)).thenReturn(Optional.of(proposedHealthPolicy));
        when(policyRepository.save(any(Policy.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Policy cancelledPolicy = policyService.performUnderwriting(1);

        assertEquals(PolicyStatus.CANCELLED, cancelledPolicy.getPolicyStatus());
        assertEquals(0.0d, cancelledPolicy.getPremiumAmount());
        assertNull(cancelledPolicy.getExpiryDate());
    }

    @Test
    void createPolicyShouldRejectBlankPolicyHolderName() {
        Policy request = new Policy();
        request.setPolicyHolderName("   ");
        request.setPolicyType(PolicyType.HEALTH);
        request.setSumInsured(200000d);

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class,
                () -> policyService.createPolicy(request));

        assertEquals("Policy holder name is required", exception.getMessage());
    }

    @Test
    void performUnderwritingShouldThrowWhenPolicyDoesNotExist() {
        when(policyRepository.findById(404)).thenReturn(Optional.empty());

        assertThrows(java.util.NoSuchElementException.class, () -> policyService.performUnderwriting(404));
    }

    @Test
    void issuePolicyShouldSetIssuedStatusAndExpiryDate() {
        proposedHealthPolicy.setPremiumAmount(10000d);
        when(policyRepository.findById(1)).thenReturn(Optional.of(proposedHealthPolicy));
        when(policyRepository.save(any(Policy.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Policy issuedPolicy = policyService.issuePolicy(1);

        assertEquals(PolicyStatus.ISSUED, issuedPolicy.getPolicyStatus());
        assertEquals(LocalDate.now().plusYears(1), issuedPolicy.getExpiryDate());
        verify(policyRepository).save(policyCaptor.capture());
        assertEquals(PolicyStatus.ISSUED, policyCaptor.getValue().getPolicyStatus());
    }

    @Test
    void issuePolicyShouldRejectPolicyWithoutUnderwriting() {
        when(policyRepository.findById(1)).thenReturn(Optional.of(proposedHealthPolicy));

        IllegalStateException exception = assertThrows(IllegalStateException.class,
                () -> policyService.issuePolicy(1));

        assertEquals("Policy must successfully complete underwriting before issuance", exception.getMessage());
    }

    @Test
    void getPolicyDetailsShouldThrowWhenPolicyDoesNotExist() {
        when(policyRepository.findById(99)).thenReturn(Optional.empty());

        assertThrows(RuntimeException.class, () -> policyService.getPolicyDetails(99));
    }
}


