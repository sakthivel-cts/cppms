package com.genc.cppms.controller;

import com.genc.cppms.enum_types.PolicyStatus;
import com.genc.cppms.enum_types.PolicyType;
import com.genc.cppms.model.Policy;
import com.genc.cppms.service.PolicyService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDate;
import java.util.NoSuchElementException;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class PolicyControllerTest {

    @Mock
    private PolicyService policyService;

    private MockMvc mockMvc;
    private Policy samplePolicy;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(new PolicyController(policyService)).build();

        samplePolicy = new Policy();
        samplePolicy.setPolicyId(10);
        samplePolicy.setPolicyHolderName("Taylor Swift");
        samplePolicy.setPolicyType(PolicyType.LIFE);
        samplePolicy.setSumInsured(500000d);
        samplePolicy.setPremiumAmount(16500d);
        samplePolicy.setPolicyStatus(PolicyStatus.ISSUED);
        samplePolicy.setExpiryDate(LocalDate.now().plusYears(1));
    }

    @Test
    void getPolicyDetailsShouldReturnPolicy() throws Exception {
        when(policyService.getPolicyDetails(10)).thenReturn(samplePolicy);

        mockMvc.perform(get("/policies/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.policyId").value(10))
                .andExpect(jsonPath("$.policyStatus").value("ISSUED"));
    }

    @Test
    void getPolicyDetailsShouldReturnNotFoundWhenMissing() throws Exception {
        when(policyService.getPolicyDetails(11)).thenThrow(new NoSuchElementException("Policy not found for id: 11"));

        mockMvc.perform(get("/policies/11"))
                .andExpect(status().isNotFound());
    }

    @Test
    void createPolicyShouldReturnBadRequestForInvalidInput() throws Exception {
        when(policyService.createPolicy(any(Policy.class)))
                .thenThrow(new IllegalArgumentException("Policy holder name is required"));

        mockMvc.perform(post("/policies/create")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{}"))
                .andExpect(status().isBadRequest());
    }

                    @Test
                    void performUnderwritingShouldReturnUpdatedPolicy() throws Exception {
                        samplePolicy.setPolicyStatus(PolicyStatus.PROPOSED);
                        when(policyService.performUnderwriting(10)).thenReturn(samplePolicy);

                        mockMvc.perform(post("/policies/underwrite/10"))
                                .andExpect(status().isOk())
                                .andExpect(jsonPath("$.policyId").value(10))
                                .andExpect(jsonPath("$.policyStatus").value("PROPOSED"));
                    }

                    @Test
                    void performUnderwritingShouldReturnNotFoundWhenPolicyMissing() throws Exception {
                        when(policyService.performUnderwriting(99))
                                .thenThrow(new NoSuchElementException("Policy not found for id: 99"));

                        mockMvc.perform(post("/policies/underwrite/99"))
                                .andExpect(status().isNotFound());
                    }

    @Test
    void issuePolicyShouldReturnConflictWhenPolicyCannotBeIssued() throws Exception {
        when(policyService.issuePolicy(10)).thenThrow(new IllegalStateException("Policy must successfully complete underwriting before issuance"));

        mockMvc.perform(post("/policies/issue/10"))
                .andExpect(status().isConflict());
    }
}



