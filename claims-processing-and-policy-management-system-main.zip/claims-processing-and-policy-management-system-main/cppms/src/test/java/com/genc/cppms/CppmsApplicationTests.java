package com.genc.cppms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CppmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
