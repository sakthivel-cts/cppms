
package com.genc.cppms.service;

import com.genc.cppms.enum_types.PolicyStatus;
import com.genc.cppms.model.Claim;
import com.genc.cppms.enum_types.ClaimStatus;
import com.genc.cppms.repository.ClaimRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;

@Service
public class ClaimService {
    private final Logger logger = LoggerFactory.getLogger(ClaimService.class);
    @Autowired
    private ClaimRepository claimRepository;

    public ResponseEntity<Claim> registerClaim(Claim claim) {
        try {
            if (claim.getPolicyId() == null) {

                throw new RuntimeException("Policy ID is required");
            }


            if (claim.getClaimAmount() == null || claim.getClaimAmount() <= 0) {

                throw new RuntimeException("Invalid claim amount");

            }

            if (claim.getClaimType() == null || claim.getClaimType().isEmpty()) {

                throw new RuntimeException("Claim type is required");

            }

            if (claim.getIncidentDate() == null) {

                throw new RuntimeException("Incident date required");

            }

            PolicyStatus policyStatus = PolicyStatus.ISSUED;

            if (!PolicyStatus.ISSUED.equals(policyStatus)) {

                throw new RuntimeException("Policy is not active");

            }

            claim.setClaimStatus(ClaimStatus.REGISTERED);

            Claim savedClaim = claimRepository.save(claim);

            return new ResponseEntity<>(savedClaim, HttpStatus.CREATED);

        } catch (Exception e) {

            logger.error("Error While Registering Claim : ", e);

            return ResponseEntity

                    .status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }
    }

    public ResponseEntity<String> uploadClaimDocuments(Integer claimId, MultipartFile file) {
        try {

            Claim claim = claimRepository.findById(claimId)
                    .orElseThrow(() -> new RuntimeException("Claim Not Found"));

            if (file.isEmpty()) {

                throw new RuntimeException("File is empty");

            }
            String fileName = System.currentTimeMillis() + "_" + file.getOriginalFilename();

            String uploadDir = System.getProperty("user.dir") + "/uploads/";

            File directory = new File(uploadDir);

            if (!directory.exists()) {

                directory.mkdir();
            }
            String filePath = uploadDir + fileName;

            file.transferTo(new File(filePath));

            claim.setDocumentPath(filePath);

            claim.setClaimStatus(ClaimStatus.UNDER_REVIEW);

            claimRepository.save(claim);

            return new ResponseEntity<>(

                    "File uploaded successfully",
                    HttpStatus.OK
            );
        } catch (Exception e) {
            logger.error("Error While Uploading Claim Documents : ", e);
            return new ResponseEntity<>(
                    "Upload failed : " + e.getMessage(),
                    HttpStatus.BAD_REQUEST
            );
        }
    }



    public ResponseEntity<String> getClaimStatus(Integer claimId) {

        Claim claim;

        try {
            claim = claimRepository.findById(claimId)

                    .orElseThrow(() -> new RuntimeException("Claim not found"));

        } catch (Exception e) {

            logger.error("Error While Fetching Claim Status : ", e);

            return new ResponseEntity<>(
                    "Some Error While Fetching Claim Status : "+e.getMessage(),
                    HttpStatus.NOT_FOUND
            );
        }

        return new ResponseEntity<>(

                claim.getClaimStatus().toString(),
                HttpStatus.OK
        );
    }
    public ResponseEntity<Claim> getClaimDetails(Integer claimId) {

        try {
            Claim claim = claimRepository.findById(claimId)
                    .orElseThrow(() -> new RuntimeException("Claim not found"));

            return new ResponseEntity<>(
                    claim,
                    HttpStatus.OK
            );

        } catch (Exception e) {
            logger.error("Error While Fetching Claim Details : ", e);

            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body(null);
        }
    }
    }

