    package com.genc.cppms.model;

    import com.genc.cppms.enum_types.PolicyStatus;
    import com.genc.cppms.enum_types.PolicyType;
    import jakarta.persistence.*;
    import lombok.*;

    import java.time.LocalDate;

    @Getter
    @Setter
    @NoArgsConstructor
    @ToString
    @Entity
    public class Policy {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Integer policyId;

        private String policyHolderName;
        private Integer age;
        @Enumerated(EnumType.STRING)
        private PolicyType policyType;
        private Double premiumAmount;
        private Double sumInsured;

        @Enumerated(EnumType.STRING)
        private PolicyStatus policyStatus;
        private LocalDate expiryDate;
    }