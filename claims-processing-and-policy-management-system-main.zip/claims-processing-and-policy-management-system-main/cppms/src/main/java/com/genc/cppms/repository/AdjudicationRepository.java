package com.genc.cppms.repository;

import com.genc.cppms.model.Settlement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdjudicationRepository extends JpaRepository<Settlement, Integer> {
    Settlement findByClaimClaimId(Integer claimId);
}
