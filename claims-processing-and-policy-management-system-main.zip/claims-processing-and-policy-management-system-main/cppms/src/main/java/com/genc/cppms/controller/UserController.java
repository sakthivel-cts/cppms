package com.genc.cppms.controller;

import com.genc.cppms.dto.ResponseData;
import com.genc.cppms.dto.UserProfileUpdateRequestDto;
import com.genc.cppms.dto.UserResponseDTO;
import com.genc.cppms.enum_types.Role;
import com.genc.cppms.model.User;
import com.genc.cppms.service.UserService;
import lombok.NonNull;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/list")
    public ResponseEntity<@NonNull ResponseData<List<UserResponseDTO>>> getUserList() {
        return ResponseEntity
                .ok(new ResponseData<>(userService.getUserList(), true,
                        "User List Retrieved Successfully!!!"));
    }

    @GetMapping("/get/{username}")
    public ResponseEntity<@NonNull ResponseData<UserResponseDTO>> getUserByUsername(@PathVariable String username) {
        return ResponseEntity
                .ok(new ResponseData<>(userService.getUserByUsername(username), true,
                        "User Details Retrieved Successfully!!!"));
    }

    @DeleteMapping("/delete")
    public ResponseEntity<@NonNull ResponseData<String>> deleteUserByUsername(@RequestParam String username, String password) {
        userService.deleteUserByUsername(username, password);
        return ResponseEntity
                .ok(new ResponseData<>("", true,
                        "User Deleted Successfully!!!"));
    }

    @PutMapping("/update")
    public ResponseEntity<@NonNull ResponseData<UserResponseDTO>> updateExistingUser(@RequestBody UserProfileUpdateRequestDto user) {
        return ResponseEntity
                .ok(new ResponseData<>(userService.updateExistingUser(user), true,
                        "User Updated Successfully!!!"));
    }
}
