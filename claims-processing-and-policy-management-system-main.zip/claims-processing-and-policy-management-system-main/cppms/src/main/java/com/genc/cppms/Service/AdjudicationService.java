package com.genc.cppms.Service;

import com.genc.cppms.enum_types.ClaimStatus;
import com.genc.cppms.enum_types.PayoutMode;
import com.genc.cppms.enum_types.PolicyStatus;
import com.genc.cppms.enum_types.SettlementStatus;
import com.genc.cppms.model.Claim;
import com.genc.cppms.model.Policy;
import com.genc.cppms.model.Settlement;
import com.genc.cppms.repository.AdjudicationRepository;
import com.genc.cppms.repository.ClaimRepository;
import com.genc.cppms.repository.PolicyRepository;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.springframework.stereotype.Service;

import java.io.File;
import java.time.LocalDate;

@Getter
@Setter
@ToString
@AllArgsConstructor
@Service
public class AdjudicationService {

    private AdjudicationRepository adjudicationRepository;

    private ClaimRepository claimRepository;

    private PolicyRepository policyRepository;

//    public String reviewClaim(Integer claimId) {
//
//        Claim claim = claimRepository.findById(claimId).orElse(new Claim());
//        claim.setClaimStatus(ClaimStatus.UNDER_REVIEW);
//        claimRepository.save(claim);
//        return "Claim " + claimId + " is under review";
//    }


    public String reviewClaim(Integer claimId) {

        //verifying details
        Claim claim = claimRepository.findById(claimId).orElse(null);
        if (claim == null) {
            return "Claim not found";
        }
        if (claim.getClaimAmount() == null || claim.getClaimAmount() <= 0) {
            return "claim amount is invalid for this claim id";
        }
        if (claim.getIncidentDate() == null ||
                claim.getIncidentDate().isAfter(java.time.LocalDate.now())) {
            return "invalid date";
        }
        Policy policy = policyRepository.findById(claim.getPolicyId()).orElse(null);
        if (policy == null) {
            return "Policy not found";
        }
        if (policy.getExpiryDate() != null && policy.getExpiryDate().isBefore(java.time.LocalDate.now())) {
            return "claim is expired";
        }

        //checking the claim status
        ClaimStatus claimStatus = claim.getClaimStatus();
        if (claimStatus == null) {
            return "Invalid claim status";
        }
        if (claimStatus == ClaimStatus.SETTLED) {
            return "claim is already settled";
        }
        if (claimStatus == ClaimStatus.REJECTED) {
            return "not found";
        }

        //eligibility checking
        PolicyStatus policyStatus = policy.getPolicyStatus();
        if (policyStatus == PolicyStatus.LAPSED || policyStatus == PolicyStatus.CANCELLED) {
            return "claim rejected";
        }
        if (policyStatus == PolicyStatus.PROPOSED || policyStatus == PolicyStatus.ISSUED) {
            Double claimAmount = claim.getClaimAmount();
            Double sumInsured = policy.getSumInsured();
            if (claimAmount == null || sumInsured == null) {
                return "Invalid data for eligibility check";
            }
            if (claimAmount > sumInsured) {
                return "Reject the claim";
            }
        }

        //document checking
        String uploadDir = System.getProperty("user.dir") + "/uploads/";
        File folder = new File(uploadDir);
        if (!folder.exists()) {
            claim.setClaimStatus(ClaimStatus.REJECTED);
            claimRepository.save(claim);
            return "file is empty";
        }
        File[] files = folder.listFiles();
        if (files == null || files.length == 0) {
            claim.setClaimStatus(ClaimStatus.REJECTED);
            claimRepository.save(claim);
            return "file is empty";
        }
        boolean fileFound = false;
        File matchedFile = null;
        for (File file : files) {
            if (file.isFile() && file.getName().contains(String.valueOf(claimId))) {
                fileFound = true;
                matchedFile = file;
                break;
            }
        }
        if (!fileFound) {
            claim.setClaimStatus(ClaimStatus.REJECTED);
            claimRepository.save(claim);
            return "file is empty";
        }
        return "Document found: " + matchedFile.getName() + ". All validations successful. Proceed for manual verification.";
    }

    //approve claim --- changes the claimStatus in the claim entity
    public Claim approveClaim(Integer claimId) {
        Claim claim = claimRepository.findById(claimId).orElseThrow(() -> new RuntimeException("Claim not found"));
        if (claim.getClaimStatus() == ClaimStatus.SETTLED) {
            throw new RuntimeException("Claim already settled");
        }
        if (claim.getClaimStatus() == ClaimStatus.REJECTED) {
            throw new RuntimeException("Claim already rejected");
        }
        claim.setClaimStatus(ClaimStatus.APPROVED);
        return claimRepository.save(claim);
    }

//    public Double calculatePayableAmount(Double claimAmount) {
//        double deduction = claimAmount * 0.10;
//        return claimAmount - deduction;
//    }

    public Settlement processSettlement(Integer claimId, PayoutMode payoutMode, Double approvedAmount) {
        Claim claim = claimRepository.findById(claimId).orElseThrow(() -> new RuntimeException("Claim not found"));
        if (!claim.getClaimStatus().equals(ClaimStatus.APPROVED)) {
            throw new RuntimeException("Settlement not allowed. Claim is not approved");
        }
        Settlement existingSettlement = adjudicationRepository.findByClaimClaimId(claimId);
        if (existingSettlement != null) {
            return existingSettlement;
        }

        Settlement settlement = new Settlement();
        settlement.setClaim(claim);
        settlement.setApprovedAmount(approvedAmount);
        settlement.setSettlementDate(LocalDate.now());
        settlement.setPayoutMode(payoutMode);
        settlement.setSettlementStatus(SettlementStatus.PAID);

        claim.setClaimStatus(ClaimStatus.SETTLED);
        claimRepository.save(claim);
        return adjudicationRepository.save(settlement);
    }

    //just created will integrate if necessary
    public Settlement getSettlementById(Integer settlementId) {
        return adjudicationRepository.findById(settlementId).orElse(null);
    }
}
