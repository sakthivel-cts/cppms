package com.genc.cppms.service;

import com.genc.cppms.model.Policy;
import com.genc.cppms.enum_types.PolicyStatus;
import com.genc.cppms.enum_types.PolicyType;
import com.genc.cppms.repository.PolicyRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PolicyService {

    private final PolicyRepository repo;

    public PolicyService(PolicyRepository repo) {
        this.repo = repo;
    }

    //CREATE POLICY
    public Policy createPolicy(Policy policy) {
        policy.setPolicyStatus(PolicyStatus.PROPOSED);//initially proposed state
        policy.setPremiumAmount(null);
        policy.setExpiryDate(LocalDate.now().plusYears(1));
        return repo.save(policy);//saved to database
    }

    //GET ALL used in policy list page
    public List<Policy> getAllPolicies() { //this method will be called when we want to display list of policies in UI
        return repo.findAll();// its like select*from policy
    }

    // GET BY ID
    public Policy getPolicyDetails(int id) {// this method will be called when we want to display details of a specific policy in UI
        return repo.findById(id)
                .orElseThrow(() -> new RuntimeException("Policy not found with id: " + id));
    }

    // CALCULATE PREMIUM
    public Policy calculatePremium(int policyId) {//this method
        // will be called when we want to calculate premium for a specific policy

        Policy policy = getPolicyDetails(policyId);//get the policy details from database

        if (policy.getSumInsured() == null || policy.getAge() == null) {
            throw new RuntimeException("Age and Sum Insured are required");
        }

        double baseRate = getBaseRate(policy.getPolicyType());
        double riskFactor = calculateRisk(policy.getAge());

        double premium = policy.getSumInsured() * baseRate * riskFactor;

        policy.setPremiumAmount(premium);

        return repo.save(policy);
    }

    //UPDATE STATUS (ISSUED / CANCELLED / LAPSED)
    public Policy updatePolicyStatus(int policyId, PolicyStatus status) {//this method will be called when we want to update the status of a specific policy

        Policy policy = getPolicyDetails(policyId);


        if (policy.getPremiumAmount() == null) {
            throw new RuntimeException("Calculate premium before updating status");
        }

        //Prevent changes if already issued
        if (policy.getPolicyStatus() == PolicyStatus.ISSUED) {
            throw new RuntimeException("Policy already issued. Cannot modify.");
        }

        policy.setPolicyStatus(status);

        return repo.save(policy);
    }

    // BASE RATE (By Policy Type)
    private double getBaseRate(PolicyType type) {
        switch (type) {
            case HEALTH:
                return 0.02;
            case LIFE:
                return 0.015;
            case VEHICLE:
                return 0.03;
            case TRAVEL:
                return 0.01;
            case HOME:
                return 0.012;
            case ACCIDENT:
                return 0.025;
            default:
                throw new RuntimeException("Invalid policy type");
        }
    }

    //RISK FACTOR (Based on Age)
    private double calculateRisk(int age) {
        if (age < 30) return 1.0;
        else if (age <= 50) return 1.2;
        else return 1.5;
    }
}