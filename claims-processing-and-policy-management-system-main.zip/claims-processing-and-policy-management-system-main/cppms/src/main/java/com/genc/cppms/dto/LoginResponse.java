package com.genc.cppms.dto;

import com.genc.cppms.dao.UserPrincipal;
import com.genc.cppms.enum_types.Role;
import com.genc.cppms.model.User;

public record LoginResponse(
        String id,
        String name,
        String username,
        Role role
) {
    public static LoginResponse from(UserPrincipal principal) {
        User u = principal.getUser();
        return new LoginResponse(
                u.getId(),
                u.getName(),
                u.getUsername(),
                u.getRole()
        );
    }
}
