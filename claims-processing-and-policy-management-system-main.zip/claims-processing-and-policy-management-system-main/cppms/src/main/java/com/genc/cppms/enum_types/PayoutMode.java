package com.genc.cppms.enum_types;

public enum PayoutMode {

    BANK_TRANSFER,
    UPI
}
