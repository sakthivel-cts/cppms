package com.genc.cppms.repository;

import com.genc.cppms.model.PremiumPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PremiumRepository extends JpaRepository<PremiumPayment, Integer> {

    List<PremiumPayment> findByPolicyIdOrderByPaymentDateDescPaymentIdDesc(int policyId);
}
