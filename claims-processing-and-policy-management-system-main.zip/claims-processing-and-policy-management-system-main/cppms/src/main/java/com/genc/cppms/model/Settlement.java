package com.genc.cppms.model;

import com.genc.cppms.enum_types.PayoutMode;
import com.genc.cppms.enum_types.SettlementStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;


@Getter @Setter @AllArgsConstructor
@NoArgsConstructor @ToString
@Entity
public class Settlement {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer settlementId;

    @OneToOne
    @JoinColumn(name = "claim_id")
    private Claim claim;

    private Double approvedAmount;
    private LocalDate settlementDate;

    @Enumerated(EnumType.STRING)
    private SettlementStatus settlementStatus;

    @Enumerated(EnumType.STRING)
    private PayoutMode payoutMode;
}
