package com.genc.cppms.enum_types;

public enum CaseStatus {
    OPEN,
    INVESTIGATING,
    CLEARED,
    CONFIRMED_FRAUD
}
