package com.genc.cppms.service;

import com.genc.cppms.dto.ResponseData;
import com.genc.cppms.dto.UserProfileUpdateRequestDto;
import com.genc.cppms.dto.UserResponseDTO;
import com.genc.cppms.enum_types.Role;
import com.genc.cppms.exception.EmptyListFoundException;
import com.genc.cppms.exception.NoDataFoundException;
import com.genc.cppms.exception.PasswordIncorrectException;
import com.genc.cppms.exception.UserAlreadyExistsException;
import com.genc.cppms.model.User;
import com.genc.cppms.repository.UserRepository;
import com.genc.cppms.util.Helper;
import lombok.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final Logger logger = LoggerFactory.getLogger(UserService.class);
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public List<UserResponseDTO> getUserList() {
        List<User> users = userRepository.findAll();
        if (users.isEmpty()) throw new EmptyListFoundException("The User List Is Empty!!!");

        List<UserResponseDTO> userResponseDTOS = new ArrayList<>();
        users.forEach(user -> userResponseDTOS.add(new UserResponseDTO(user)));

        return userResponseDTOS;
    }

    public UserResponseDTO getUserByUsername(@NonNull String username) {
        User user = userRepository.findByUsername(username);
        if (user == null) throw new NoDataFoundException("User Doesn't Exists!!!");
        return new UserResponseDTO(user);
    }

    public void deleteUserByUsername(String username, String password) {
        User user = userRepository.findByUsername(username);

        if (user == null) throw new NoDataFoundException("User Doesn't Exists!!!");
        if (user.getPassword().equals(passwordEncoder.encode(password))) throw new PasswordIncorrectException("The Entered Password Is Incorrect!!!");

        userRepository.deleteByUsername(username);
    }

    public UserResponseDTO updateExistingUser(UserProfileUpdateRequestDto user) {
        User existingUser = userRepository.findByUsername(user.username());

        if (userRepository.existsByUsername(user.newUsername())) throw new UserAlreadyExistsException("Username is Already Taken!!!");

        existingUser.setName(user.name());
        existingUser.setRole(user.role());
        existingUser.setUsername(user.newUsername());

        return new UserResponseDTO(userRepository.save(existingUser));
    }
}
