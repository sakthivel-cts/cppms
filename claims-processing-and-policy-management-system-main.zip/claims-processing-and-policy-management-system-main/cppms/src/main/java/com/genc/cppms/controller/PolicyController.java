package com.genc.cppms.controller;

import com.genc.cppms.model.Policy;
import com.genc.cppms.enum_types.PolicyStatus;
import com.genc.cppms.service.PolicyService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/policies")
public class PolicyController {

    private final PolicyService service;

    public PolicyController(PolicyService service) {
        this.service = service;
    }

    //1. Create Policy
    @PostMapping("/create")
    public Policy createPolicy(@RequestBody Policy policy) {
        return service.createPolicy(policy);
    }

    // 2. Get All Policies (List Page)
    @GetMapping("/all")
    public List<Policy> getAllPolicies() {
        return service.getAllPolicies();
    }

    // 3. Get Policy Details (View Page)
    @GetMapping("/{id}")
    public Policy getPolicyDetails(@PathVariable int id) {
        return service.getPolicyDetails(id);
    }

    // 4. Calculate Premium
    @PostMapping("/calculate/{id}")
    public Policy calculatePremium(@PathVariable int id) {
        return service.calculatePremium(id);
    }

    // 5. Update Status (ISSUED / CANCELLED / LAPSED)
    @PostMapping("/status/{id}")
    public Policy updatePolicyStatus(@PathVariable int id,
                                     @RequestParam PolicyStatus status) {
        return service.updatePolicyStatus(id, status);
    }
}