package com.genc.cppms.enum_types;

public enum SettlementStatus {

    PENDING,
    PAID,
    ON_HOLD
}
