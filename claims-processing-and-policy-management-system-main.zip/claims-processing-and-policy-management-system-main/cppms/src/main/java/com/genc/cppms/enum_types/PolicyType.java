package com.genc.cppms.enum_types;

public enum PolicyType {

    HEALTH,
    LIFE,
    VEHICLE,
    TRAVEL,
    HOME,
    ACCIDENT

}
