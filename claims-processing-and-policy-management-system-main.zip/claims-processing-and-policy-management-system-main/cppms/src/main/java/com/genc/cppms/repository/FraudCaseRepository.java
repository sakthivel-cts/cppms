package com.genc.cppms.repository;

import com.genc.cppms.model.FraudCase;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FraudCaseRepository extends JpaRepository<FraudCase, String> {
}
