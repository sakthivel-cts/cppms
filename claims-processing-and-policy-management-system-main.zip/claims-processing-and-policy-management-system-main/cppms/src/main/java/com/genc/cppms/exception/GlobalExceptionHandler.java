package com.genc.cppms.exception;

import com.genc.cppms.dto.ResponseData;
import lombok.NonNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(EmptyListFoundException.class)
    public ResponseEntity<@NonNull ResponseData<Object>> handleEmptyListFoundException(EmptyListFoundException e) {
        logger.warn("Empty List Found!!!", e);
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(new ResponseData<>(null, false, e.getMessage()));
    }

    @ExceptionHandler(NoDataFoundException.class)
    public ResponseEntity<@NonNull ResponseData<Object>> handleNoDataFoundException(NoDataFoundException e) {
        logger.warn("No Data Found!!!", e);
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(new ResponseData<>(null, false, e.getMessage()));
    }

    @ExceptionHandler(UserAlreadyExistsException.class)
    public ResponseEntity<@NonNull ResponseData<Object>> handleUserAlreadyExistsException(UserAlreadyExistsException e) {
        logger.warn("Username is Taken!!!", e);
        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(new ResponseData<>(null, false, e.getMessage()));
    }

    @ExceptionHandler(PasswordIncorrectException.class)
    public ResponseEntity<@NonNull ResponseData<Object>> handlePasswordIncorrectException(PasswordIncorrectException e) {
        logger.warn("The Password Is Incorrect", e);
        return ResponseEntity
                .status(HttpStatus.UNAUTHORIZED)
                .body(new ResponseData<>(null, false, e.getMessage()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<@NonNull ResponseData<Object>> handleGeneric(Exception e) {
        logger.error("Internal Server Error", e);
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ResponseData<>(null, false, "Internal Server Error : "+e.getMessage()));
    }
}
