package com.genc.cppms.controller;

import com.genc.cppms.dto.ResponseData;
import com.genc.cppms.model.FraudCase;
import com.genc.cppms.service.FraudCaseService;
import lombok.NonNull;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/fraud-case")
public class FraudCaseController {

    private final FraudCaseService fraudCaseService;

    public FraudCaseController(FraudCaseService fraudCaseService) {
        this.fraudCaseService = fraudCaseService;
    }

    @GetMapping("/get/{caseId}")
    public ResponseEntity<@NonNull ResponseData<FraudCase>> getParticularFraudCase(@PathVariable String caseId) {
        FraudCase fraudCase = fraudCaseService.getParticularFraudCase(caseId);

        return ResponseEntity.ok(new ResponseData<>(fraudCase, true,
                "Fraud Case Retrieved Successfully!!!"
        ));
    }

    @GetMapping("/list")
    public ResponseEntity<@NonNull ResponseData<List<FraudCase>>> getFraudCaseList() {
        List<FraudCase> fraudCases = fraudCaseService.getFraudCaseList();

        return ResponseEntity.ok(new ResponseData<>(fraudCases, true,
                "Fraud Case List Retrieved Successfully!!!"
        ));
    }

    @PostMapping("/flag/{claimId}")
    public ResponseEntity<@NonNull ResponseData<FraudCase>> flagSuspiciousClaim(@PathVariable int claimId) {
        FraudCase fraudCase = fraudCaseService.flagSuspiciousClaim(claimId);

        return ResponseEntity.ok(new ResponseData<>(fraudCase, true,
                "Claim Flagged As Suspicious!!!!"
        ));
    }

    @GetMapping("/assign")
    public ResponseEntity<@NonNull ResponseData<FraudCase>> assignInvestigator(@RequestParam String username, String caseId) {
        FraudCase fraudCase = fraudCaseService.assignInvestigator(username, caseId);
        return ResponseEntity.ok(new ResponseData<>(fraudCase, true,
                "Investigator Assigned To The Fraud Case Successfully!!!"
        ));
    }
}
