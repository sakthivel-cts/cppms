package com.genc.cppms.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.genc.cppms.enum_types.CaseStatus;
import jakarta.persistence.*;
import lombok.*;

@Setter @Getter @ToString @Builder
@AllArgsConstructor @NoArgsConstructor
@Entity
public class FraudCase {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String caseId;

    @OneToOne(cascade = {CascadeType.DETACH, CascadeType.MERGE})
    @JoinColumn(name = "claim_id")
    private Claim claim;

    private int fraudScore;
    private String findingSummary;

    @Enumerated(EnumType.STRING)
    private CaseStatus caseStatus;

    @ManyToOne(cascade = {CascadeType.DETACH, CascadeType.MERGE})
    @JoinColumn(name = "investigator_id")
    @JsonIgnoreProperties({"fraudCases", "password"})
    private User investigator;
}
