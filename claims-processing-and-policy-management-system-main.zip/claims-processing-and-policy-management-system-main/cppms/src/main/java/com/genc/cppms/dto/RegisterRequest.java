package com.genc.cppms.dto;

import com.genc.cppms.enum_types.Role;

public record RegisterRequest(
        String name,
        String username,
        String password,
        Role role
) {
}
