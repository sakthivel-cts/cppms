package com.genc.cppms.exception;

public class RoleBasedException extends RuntimeException {
    public RoleBasedException(String message) {
        super(message);
    }
}
