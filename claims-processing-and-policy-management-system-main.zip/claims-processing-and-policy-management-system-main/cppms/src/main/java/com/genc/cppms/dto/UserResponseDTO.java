package com.genc.cppms.dto;

import com.genc.cppms.enum_types.Role;
import com.genc.cppms.model.User;

public record UserResponseDTO (
        String id,
        String name,
        String username,
        Role role
) {

    public UserResponseDTO(User user) {
        this(user.getId(), user.getName(), user.getUsername(), user.getRole());
    }
}
