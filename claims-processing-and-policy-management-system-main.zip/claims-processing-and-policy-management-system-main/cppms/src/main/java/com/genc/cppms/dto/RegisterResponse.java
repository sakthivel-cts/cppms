package com.genc.cppms.dto;

import com.genc.cppms.enum_types.Role;
import com.genc.cppms.model.User;
import lombok.NonNull;

public record RegisterResponse(
        String id,
        String name,
        String username,
        Role role
) {

    public RegisterResponse(@NonNull User user) {
        this(user.getId(), user.getName(), user.getUsername(), user.getRole());
    }
}
