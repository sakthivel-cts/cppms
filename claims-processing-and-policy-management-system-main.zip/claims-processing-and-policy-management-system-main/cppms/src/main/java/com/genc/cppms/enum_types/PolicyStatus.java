package com.genc.cppms.enum_types;

public enum PolicyStatus {

    PROPOSED,
    ISSUED,
    ACTIVE,
    CANCELLED,
    LAPSED

}
