package com.genc.cppms.exception;

public class EmptyListFoundException extends RuntimeException {
    public EmptyListFoundException(String message) {
        super(message);
    }
}
