package com.genc.cppms.dto;

public record ResponseData<E>(E data, boolean success, String message) {
}
