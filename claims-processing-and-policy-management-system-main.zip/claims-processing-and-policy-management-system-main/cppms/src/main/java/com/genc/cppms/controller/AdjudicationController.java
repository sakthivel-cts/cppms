package com.genc.cppms.controller;

import com.genc.cppms.Service.AdjudicationService;
import com.genc.cppms.enum_types.ClaimStatus;
import com.genc.cppms.enum_types.PayoutMode;
import com.genc.cppms.model.Claim;
import com.genc.cppms.model.Settlement;
import com.genc.cppms.repository.ClaimRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.File;


@Data
@AllArgsConstructor
@RestController
@RequestMapping("/adjudication")
@CrossOrigin(origins = {"http://127.0.0.1:5500"})
public class AdjudicationController {

    private AdjudicationService adjudicationService;
    private ClaimRepository claimRepository;

    @GetMapping("/review/{claimId}")
    public String reviewClaim(@PathVariable Integer claimId) {
        return adjudicationService.reviewClaim(claimId);
    }

    @PutMapping("/approve/{claimId}")
    public Claim approveClaim(@PathVariable Integer claimId) {
        return adjudicationService.approveClaim(claimId);
    }

    @PutMapping("/reject/{claimId}")
    public String rejectClaim(@PathVariable Integer claimId) {

        Claim claim = claimRepository.findById(claimId).orElseThrow(() -> new RuntimeException("Claim not found"));

        claim.setClaimStatus(ClaimStatus.REJECTED);

        claimRepository.save(claim);

        return "Claim Rejected";
    }

    @GetMapping("/open-document/{claimId}")
    public ResponseEntity<Resource> openDocument(@PathVariable Integer claimId) throws Exception {

        String uploadDir = System.getProperty("user.dir") + "/uploads/";
        File folder = new File(uploadDir);

        for (File file : folder.listFiles()) {

            if (file.getName().contains(String.valueOf(claimId))) {

                Resource resource = new UrlResource(file.toURI());

                return ResponseEntity.ok()
                        .header("Content-Disposition", "inline; filename=" + file.getName())
                        .body(resource);
            }
        }

        throw new RuntimeException("File not found");
    }

    @PostMapping("/settlement/{claimId}")
    public Settlement processSettlement(@PathVariable Integer claimId, @RequestParam PayoutMode payoutMode, @RequestParam Double approvedAmount) {
        return adjudicationService.processSettlement(claimId, payoutMode, approvedAmount);
    }
}

//    @PostMapping("/settlement/{claimId}")
//    public Settlement processSettlement(@PathVariable Integer claimId, @RequestParam PayoutMode payoutMode) {
//        return adjudicationService.processSettlement(claimId, payoutMode);
//    }
//    @GetMapping("/settlement/{settlementId}")
//    public Settlement getSettlementById(@PathVariable Integer settlementId) {
//        return adjudicationService.getSettlementById(settlementId);
//    }
