package com.genc.cppms.enum_types;

public enum ClaimStatus {

    REGISTERED,
    UNDER_REVIEW,
    APPROVED,
    REJECTED,
    SETTLED

}
