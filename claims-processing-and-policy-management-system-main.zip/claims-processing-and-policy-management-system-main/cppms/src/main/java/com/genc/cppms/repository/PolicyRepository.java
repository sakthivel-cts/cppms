package com.genc.cppms.repository;

import com.genc.cppms.model.Policy;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PolicyRepository extends JpaRepository<Policy,Integer> {
}
