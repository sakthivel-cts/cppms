package com.genc.cppms.controller;

import com.genc.cppms.model.Claim;
import com.genc.cppms.service.ClaimService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/claims")
public class ClaimController {

    @Autowired
    private ClaimService claimService;


    @PostMapping("/register")
    public ResponseEntity<Claim> registerClaim(@RequestBody Claim claim) {

        return claimService.registerClaim(claim);
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadDocuments(

            @RequestParam Integer claimId,
            @RequestParam("file") MultipartFile file) {

        return claimService.uploadClaimDocuments(claimId, file);
    }


    @GetMapping("/{id}")

    public ResponseEntity<String> getClaimStatus(@PathVariable Integer id)
    {
        return claimService.getClaimStatus(id);
    }



    @GetMapping("/details/{id}")
    public ResponseEntity<Claim> getClaimDetails(@PathVariable Integer id) {
        return claimService.getClaimDetails(id);
    }

}