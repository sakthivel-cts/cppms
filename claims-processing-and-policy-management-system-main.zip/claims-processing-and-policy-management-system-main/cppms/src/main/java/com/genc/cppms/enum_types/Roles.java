package com.genc.cppms.enum_types;

public enum Roles {

    UNDERWRITER,
    PolicyAdministrator,
    ClaimsAdjuster,
    FraudInvestigator,
    Admin
}
