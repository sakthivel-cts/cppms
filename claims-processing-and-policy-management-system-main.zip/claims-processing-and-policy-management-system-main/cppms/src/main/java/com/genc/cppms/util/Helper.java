package com.genc.cppms.util;

public class Helper {

    private Helper() {}

    public static int generateRandomScore() {
        return Math.toIntExact(Math.round(Math.random() * 100));
    }
}
