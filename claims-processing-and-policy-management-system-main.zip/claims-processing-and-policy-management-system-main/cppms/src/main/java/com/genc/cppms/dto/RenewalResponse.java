package com.genc.cppms.dto;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RenewalResponse {

    private int policyId;
    private String policyHolderName;
    private String policyStatus;
    private LocalDate expiryDate;
    private double premiumAmount;
    private long daysUntilExpiry;
    private boolean renewalEligible;
    private String message;
}