package com.genc.cppms.controller;

import com.genc.cppms.dao.UserPrincipal;
import com.genc.cppms.dto.LoginRequest;
import com.genc.cppms.dto.LoginResponse;
import com.genc.cppms.dto.RegisterRequest;
import com.genc.cppms.dto.RegisterResponse;
import com.genc.cppms.exception.NoDataFoundException;
import com.genc.cppms.service.LoginAndRegisterService;
import lombok.NonNull;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/auth")
public class LoginAndRegisterController {

    private final LoginAndRegisterService loginAndRegisterService;
    private final AuthenticationManager authenticationManager;

    public LoginAndRegisterController(
            LoginAndRegisterService loginAndRegisterService,
            AuthenticationManager authenticationManager
    ) {
        this.loginAndRegisterService = loginAndRegisterService;
        this.authenticationManager = authenticationManager;
    }

    @PostMapping("/login")
    public ResponseEntity<@NonNull LoginResponse> login(@RequestBody LoginRequest loginRequest) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        loginRequest.username(),
                        loginRequest.password()
                )
        );

        UserPrincipal user = (UserPrincipal) authentication.getPrincipal();
        if (user == null) throw new NoDataFoundException("User Not ");
        return ResponseEntity.ok(LoginResponse.from(user));
    }

    @PostMapping("/register")
    public ResponseEntity<@NonNull RegisterResponse> register(@RequestBody RegisterRequest registerRequest) {
        return ResponseEntity.ok(loginAndRegisterService.registerNewUser(registerRequest));
    }
}
