package com.genc.cppms.service;
import com.genc.cppms.enum_types.PolicyStatus;
import com.genc.cppms.model.Policy;
import com.genc.cppms.model.PremiumPayment;
import com.genc.cppms.repository.PolicyRepository;
import com.genc.cppms.repository.PremiumRepository;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.Set;



@Service
public class PremiumService {


    private static final Set<String> SUPPORTED_PAYMENT_MODES = Set.of("UPI", "CARD", "NET BANKING", "CASH");

    private final PremiumRepository premiumRepository;
    private final PolicyRepository policyRepository;

    public PremiumService(PremiumRepository premiumRepository, PolicyRepository policyRepository) {
        this.premiumRepository = premiumRepository;
        this.policyRepository = policyRepository;
    }
//record premium payment
    public PremiumPayment recordPremiumPayment(PremiumPayment payment) {
        validatePaymentRequest(payment);

        Policy policy = getPolicyOrThrow(payment.getPolicyId());
        validatePolicyForCollection(policy);

        PremiumPayment premiumPayment = preparePayment(payment);

        if (!SUPPORTED_PAYMENT_MODES.contains(premiumPayment.getPaymentMode())) {
            premiumPayment.setPaymentStatus("FAILED");
            return premiumRepository.save(premiumPayment);
        }

        if (premiumPayment.getAmountPaid() != policy.getPremiumAmount()) {
            premiumPayment.setPaymentStatus("PENDING");
            return premiumRepository.save(premiumPayment);
        }

        premiumPayment.setPaymentStatus("RECEIVED");
        PremiumPayment savedPayment = premiumRepository.save(premiumPayment);
        return savedPayment;
    }

    public List<PremiumPayment> getPremiumHistory(int policyId) {
        validatePolicyId(policyId);
        getPolicyOrThrow(policyId);
        return premiumRepository.findByPolicyIdOrderByPaymentDateDescPaymentIdDesc(policyId);
    }

    //validate

    private void validatePaymentRequest(PremiumPayment payment) {
        if (payment == null) {
            throw new IllegalArgumentException("Payment request is required");
        }

        validatePolicyId(payment.getPolicyId());

        if (payment.getAmountPaid() <= 0) {
            throw new IllegalArgumentException("Amount paid must be greater than zero");
        }

        if (payment.getPaymentMode() == null || payment.getPaymentMode().isBlank()) {
            throw new IllegalArgumentException("Payment mode is required");
        }
    }

    private void validatePolicyId(int policyId) {
        if (policyId <= 0) {
            throw new IllegalArgumentException("Valid policy id is required");
        }
    }

    private Policy getPolicyOrThrow(int policyId) {
        return policyRepository.findById(policyId)
                .orElseThrow(() -> new NoSuchElementException("Policy not found for id: " + policyId));
    }

    private void validatePolicyForCollection(Policy policy) {
        if (policy.getPolicyStatus() == PolicyStatus.CANCELLED) {
            throw new IllegalStateException("Premium cannot be collected for a cancelled policy");
        }

        if (policy.getPolicyStatus() == PolicyStatus.PROPOSED) {
            throw new IllegalStateException("Premium cannot be collected before policy issuance");
        }
    }

    private PremiumPayment preparePayment(PremiumPayment payment) {
        payment.setPaymentMode(payment.getPaymentMode().trim().toUpperCase(Locale.ROOT));
        payment.setPaymentDate(LocalDate.now());
        return payment;
    }
}