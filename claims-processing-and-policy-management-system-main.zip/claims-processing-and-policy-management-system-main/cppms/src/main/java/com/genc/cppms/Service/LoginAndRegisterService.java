package com.genc.cppms.service;

import com.genc.cppms.dao.UserPrincipal;
import com.genc.cppms.dto.RegisterRequest;
import com.genc.cppms.dto.RegisterResponse;
import com.genc.cppms.exception.UserAlreadyExistsException;
import com.genc.cppms.model.User;
import com.genc.cppms.repository.UserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class LoginAndRegisterService implements UserDetailsService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public LoginAndRegisterService(
            UserRepository userRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        if (user == null) throw new UsernameNotFoundException("Username Not Found!!!");
        return new UserPrincipal(user);
    }

    public RegisterResponse registerNewUser(RegisterRequest registerRequest) {
        User user = User.builder()
                .name(registerRequest.name())
                .username(registerRequest.username())
                .password(passwordEncoder.encode(registerRequest.password()))
                .role(registerRequest.role())
                .build();

        if (userRepository.existsByUsername(user.getUsername())) throw new UserAlreadyExistsException("The Username is Taken!!!");

        User storedUser = userRepository.save(user);
        return new RegisterResponse(storedUser);
    }
}
