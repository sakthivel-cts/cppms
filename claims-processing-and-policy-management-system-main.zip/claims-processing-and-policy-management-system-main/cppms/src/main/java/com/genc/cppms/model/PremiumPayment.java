package com.genc.cppms.model;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "PremiumPayment")
@Getter
@Setter
public class PremiumPayment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int paymentId;
    private int policyId;
    private double amountPaid;
    private String paymentMode;
    private String paymentStatus;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate paymentDate;
}