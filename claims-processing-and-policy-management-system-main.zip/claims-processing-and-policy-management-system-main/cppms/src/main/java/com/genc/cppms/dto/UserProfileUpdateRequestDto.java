package com.genc.cppms.dto;

import com.genc.cppms.enum_types.Role;

public record UserProfileUpdateRequestDto(
        String id,
        String name,
        String username,
        String newUsername,
        Role role
) {
}
