package com.genc.cppms.service;

import com.genc.cppms.enum_types.CaseStatus;
import com.genc.cppms.enum_types.Role;
import com.genc.cppms.exception.EmptyListFoundException;
import com.genc.cppms.exception.NoDataFoundException;
import com.genc.cppms.exception.RoleBasedException;
import com.genc.cppms.model.Claim;
import com.genc.cppms.model.FraudCase;
import com.genc.cppms.model.User;
import com.genc.cppms.repository.ClaimRepository;
import com.genc.cppms.repository.FraudCaseRepository;
import com.genc.cppms.repository.UserRepository;
import com.genc.cppms.util.Helper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class FraudCaseService {

    private final FraudCaseRepository fraudCaseRepository;
    private final ClaimRepository claimRepository;
    private final UserRepository userRepository;

    public FraudCaseService(
            FraudCaseRepository fraudCaseRepository,
            ClaimRepository claimRepository,
            UserRepository userRepository
    ) {
        this.fraudCaseRepository = fraudCaseRepository;
        this.claimRepository = claimRepository;
        this.userRepository = userRepository;
    }

    public List<FraudCase> getFraudCaseList() {
        List<FraudCase> fraudCases = fraudCaseRepository.findAll();
        if (fraudCases.isEmpty()) throw new EmptyListFoundException("The Fraud Case List Was Empty");
        return fraudCaseRepository.findAll();
    }

    public FraudCase flagSuspiciousClaim(int claimId) {
        Claim claim = claimRepository.findById(claimId)
                .orElseThrow(() -> new NoDataFoundException("No Claim Found For The ID"));

        FraudCase fraudCase = FraudCase.builder()
                .claim(claim)
                .fraudScore(Helper.generateRandomScore())
                .caseStatus(CaseStatus.OPEN)
                .findingSummary("Initial suspicion detected")
                .build();

        return fraudCaseRepository.save(fraudCase);
    }

    public FraudCase assignInvestigator(String username, String caseId) {
        User user = userRepository.findByUsername(username);

        if (user == null) throw new NoDataFoundException("User Not Found!!!");
        if (!user.getRole().equals(Role.FRAUD_INVESTIGATOR)) throw new RoleBasedException("The User is Not A Fraud Investigator!!!");

        FraudCase fraudCase = fraudCaseRepository.findById(caseId)
                .orElseThrow(() -> new NoDataFoundException("Fraud Case Not Found!!!"));

        if (fraudCase.getInvestigator() != null) throw new RoleBasedException("Investigator Already Assigned To The Fraud Case!!!");

        List<FraudCase> fraudCases = user.getFraudCases();
        fraudCases.add(fraudCase);
        user.setFraudCases(fraudCases);

        fraudCase.setInvestigator(user);

        userRepository.save(user);

        return fraudCase;
    }

    public FraudCase getParticularFraudCase(String caseId) {
        return fraudCaseRepository.findById(caseId)
                .orElseThrow(() -> new NoDataFoundException("Fraud Case Was Not Found For The Case Id Mentioned!!!"));
    }

//    public ResponseEntity<@NonNull ResponseData<FraudCase>> logInvestigationFinding() {
//        FraudCase fraudCase = null;
//        try {
//
//        } catch (Exception e) {
//            logger.error("Error While Fetching Particular Fraud Case", e);
//            return new ResponseEntity<>(
//                    new ResponseData<>(null, false, e.getMessage()),
//                    HttpStatus.INTERNAL_SERVER_ERROR
//            );
//        }
//        return new ResponseEntity<>(
//                new ResponseData<>(fraudCase, true, "Investigator Added To The Fraud Case"),
//                HttpStatus.OK
//        );
//    }
}
