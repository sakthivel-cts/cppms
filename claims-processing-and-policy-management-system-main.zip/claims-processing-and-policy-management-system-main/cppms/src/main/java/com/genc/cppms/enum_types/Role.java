package com.genc.cppms.enum_types;

public enum Role {

    UNDERWRITER,
    POLICY_ADMINISTRATOR,
    CLAIMS_ADJUSTER,
    FRAUD_INVESTIGATOR,
    ADMIN
}
