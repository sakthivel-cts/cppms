package com.genc.cppms.controller;
import com.genc.cppms.model.PremiumPayment;
import com.genc.cppms.service.PremiumService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/premium")
@CrossOrigin(origins = "*")
public class PremiumController {

    private final PremiumService premiumService;

    public PremiumController(PremiumService premiumService) {

        this.premiumService = premiumService;
    }

    @PostMapping({"/pay", "/payments"})
    public ResponseEntity<PremiumPayment> recordPremiumPayment(@RequestBody PremiumPayment payment) {
        PremiumPayment savedPayment = premiumService.recordPremiumPayment(payment);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedPayment);
    }

    @GetMapping({"/history/{policyId}", "/policies/{policyId}/history"})
    public ResponseEntity<List<PremiumPayment>> getPremiumHistory(@PathVariable int policyId) {
        return ResponseEntity.ok(premiumService.getPremiumHistory(policyId));
    }
}
