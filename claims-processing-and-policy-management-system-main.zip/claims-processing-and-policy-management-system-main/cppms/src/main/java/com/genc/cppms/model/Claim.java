package com.genc.cppms.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.genc.cppms.enum_types.ClaimStatus;
import jakarta.persistence.*;
import java.time.LocalDate;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.*;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Claim")
public class Claim {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer claimId;

    private Integer policyId;

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate incidentDate;

    private Double claimAmount;

    private String claimType;

    @Enumerated(EnumType.STRING)
    private ClaimStatus claimStatus;

    private String documentPath;
    @OneToOne(mappedBy = "claim")
    @JsonIgnore
    private FraudCase fraudCase;

    @PrePersist
    public void setDefaultStatus() {
        if (this.claimStatus == null) {
            this.claimStatus = ClaimStatus.REGISTERED;
        }
    }

}
