package com.genc.cppms.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.genc.cppms.enum_types.Role;
import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Queue;
import java.util.Set;

@Setter @Getter @ToString
@AllArgsConstructor @NoArgsConstructor
@Entity @Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private String id;

    @Column(nullable = false)
    private String name;

    @Column(unique = true, nullable = false)
    private String username;
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Role role;

    @OneToMany(mappedBy = "investigator", orphanRemoval = true)
    @JsonIgnoreProperties({"investigator", "claim"})
    private List<FraudCase> fraudCases = new ArrayList<>();

    public void updateObjData(@NonNull User user) {
        this.name = user.getName();
        this.username = user.getUsername();
        this.password = user.getPassword();
        this.role = user.getRole();
    }
}
