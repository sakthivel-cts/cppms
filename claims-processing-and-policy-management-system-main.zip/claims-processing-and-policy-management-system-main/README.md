# 📌 Claims Processing & Policy Management System

## 📖 Overview
The **Claims Processing & Policy Management System** is an insurance-based web application that manages the complete lifecycle of insurance operations.  
It handles everything from policy creation to claim settlement, including fraud detection.

This project is designed using a modular architecture where each module represents a real-world insurance process in a simplified way.

---

## 🎯 Features
- Policy creation and underwriting
- Premium payment and renewal tracking
- Claim registration and document verification
- Claim approval and settlement
- Fraud detection and investigation tracking
- Role-based access control

---

## 🏗️ Modules

### 1. Policy Issuance & Underwriting
- Create and manage policies
- Risk evaluation by underwriter
- Premium calculation and policy approval

---

### 2. Premium Collection & Renewal
- Record premium payments
- Track payment history
- Handle policy renewal and reminders

---

### 3. Claim Intake & Document Verification
- Register insurance claims
- Upload and verify documents
- Track claim status

---

### 4. Claim Adjudication & Settlement
- Review claims
- Approve or reject claims
- Process settlement payments

---

### 5. Fraud Detection & Investigation
- Identify suspicious claims
- Assign investigators
- Track investigation results

---

## 👥 Roles in the System
- **Underwriter** – Evaluates risk and decides premium  
- **Policy Administrator** – Creates and manages policies  
- **Claims Adjuster** – Reviews and processes claims  
- **Fraud Investigator** – Handles fraud cases  
- **Admin** – Manages users and monitors the system  

---

<!-- ## Diagrams
![Workflow](./diagrams/Workflow.png)
--- -->

## 🧑‍🤝‍🧑 Team Members
- Sakthivel D  
- Adithya M  
- Shaileas Babu M  
- Nigashini K  
- Veena L  

---

## 💻 Tech Stack

### 🔹 Frontend
- HTML  
- CSS  
- JavaScript  
- Bootstrap  

### 🔹 Backend
- Spring Boot  
- REST APIs  

---

## 🚀 Getting Started

1. Clone the repository 
```
git clone https://github.com/sakthivel-cts/claims-processing-and-policy-management-system.git
```

2. Configure database

3. Run the backend (Spring Boot)

4. Open frontend in browser

---


## All API Endpoints List [POSTMAN](https://sakthivel-d-4c8e9a3f-52794.postman.co/workspace/69e005ee-78f3-4677-bcf6-eb66aa846df8)
```bash
https://sakthivel-d-4c8e9a3f-52794.postman.co/workspace/69e005ee-78f3-4677-bcf6-eb66aa846df8
```
---
