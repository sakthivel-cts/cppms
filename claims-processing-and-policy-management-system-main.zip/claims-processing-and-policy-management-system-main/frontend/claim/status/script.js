const BASE_URL = "http://localhost:8090/claims";

window.onload = function () {
    const claimId = localStorage.getItem("claimId");

    if (claimId) {
        document.getElementById("claimId").value = claimId;
        fetchStatus(claimId);
    }
};

function checkStatus() {
    const claimId = document.getElementById("claimId").value;
    fetchStatus(claimId);
}

async function fetchStatus(claimId) {
    const statusResult = document.getElementById("statusResult");

    try {
        const res = await fetch(BASE_URL + "/" + claimId);

        if (!res.ok) throw new Error("Not found");

        const result = await res.text();

        statusResult.innerHTML =
            "<span class='text-success'>Status: " + result + "</span>";

    } catch (err) {
        statusResult.innerHTML =
            "<span class='text-danger'> " + err.message + "</span>";
    }
}
