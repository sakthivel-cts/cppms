const BASE_URL = "http://localhost:8090/claims";

document.getElementById("claimForm").addEventListener("submit", async function(e) {
    e.preventDefault();

    const submitBtn = document.querySelector("button");

    submitBtn.disabled = true;

    const data = {
        policyId: parseInt(document.getElementById("policyId").value),
        claimType: document.getElementById("claimType").value,
        incidentDate: document.getElementById("incidentDate").value,
        claimAmount: parseFloat(document.getElementById("claimAmount").value)
    };

    try {
        const res = await fetch(BASE_URL + "/register", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });

        if (!res.ok) throw new Error("Server Error");

        const result = await res.json();

        localStorage.setItem("claimId", result.claimId);

        document.getElementById("resultMsg").innerHTML =
            " Claim Registered! Your Claim ID: " + result.claimId;

        setTimeout(() => {
            window.location.href = "upload-documents/";
        }, 1500);

    } catch (err) {
        document.getElementById("resultMsg").innerText =
            " Failed: " + err.message;
    } finally {
        submitBtn.disabled = false;
    }
});
