const BASE_URL = "http://localhost:8090/claims";

window.onload = function () {
    const claimId = localStorage.getItem("claimId");
   

    if (claimId) {
        document.getElementById("claimId").value = claimId;
    }
};

document.getElementById("docForm").addEventListener("submit", async function (e) {
    e.preventDefault();

    const claimId = document.getElementById("claimId").value;
    const fileInput = document.getElementById("file");
    const uploadMsg = document.getElementById("uploadMsg");

    if (!fileInput.files.length) {
        uploadMsg.innerText = " Please select a file";
        return;
    }

    const formData = new FormData();
    formData.append("claimId", claimId);
    formData.append("file", fileInput.files[0]);

    try {
        const res = await fetch(BASE_URL + "/upload", {
            method: "POST",
            body: formData
        });

        if (!res.ok) throw new Error("Upload failed");

        const result = await res.text();

        uploadMsg.innerText = "" + result;

        setTimeout(() => {
            window.location.href = "/claim/status";
        }, 1500);

    } catch (err) {
        uploadMsg.innerText = "❌ " + err.message;
    }
});