document.getElementById("contactForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const data = {
        name: name.value,
        email: email.value,
        phone: phone.value,
        topic: topic.value,
        message: message.value
    };

    console.log(data);

    document.getElementById("responseMsg").innerText =
        "Message submitted successfully ✅";

    this.reset();
});