import company_details from "./details.js";

var company_title = document.getElementsByClassName("company-name");

for(let i=0;i<company_title.length;i++)
    company_title[i].innerText = company_details.name;


const redirectTo404ErrorPage = () => {
    try {
        window.location.href = "/auth/404.html";
    } catch (err) {
        console.log(err.message);
    }
}

const getAuthHeaders = () => {
  const username = "shaileas";
  const password = "shaileas";

  return `Basic ${btoa(username + ":" + password)}`;
}

const changeEnumToStringForRole = (role) => {
    switch(role) {
        case "FRAUD_INVESTIGATOR" : return "FRAUD INVESTIGATOR";
        case "POLICY_ADMINISTRATOR" : return "POLICY ADMINISTRATOR";
        default : return role;
    }
}

export { redirectTo404ErrorPage, getAuthHeaders, changeEnumToStringForRole };