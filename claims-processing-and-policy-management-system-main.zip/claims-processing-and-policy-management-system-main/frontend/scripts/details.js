const company_details = {

    "name" : "Nothing Insurance Company"
}

export default company_details;