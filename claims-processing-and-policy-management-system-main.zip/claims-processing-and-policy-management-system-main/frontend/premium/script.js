const policyIdInput = document.getElementById("policyId");
const message = document.getElementById("message");
const paymentBtn = document.getElementById("paymentBtn");
const historyBtn = document.getElementById("historyBtn");
const renewalBtn = document.getElementById("renewalBtn");

function getPolicyId() {
    const value = Number(policyIdInput.value);

    if (!value || value <= 0) {
        message.textContent = "Please enter a valid policy ID.";
        policyIdInput.focus();
        return null;
    }

    message.textContent = "";
    return value;
}

function goTo(routeName) {
    const policyId = getPolicyId();
    if (!policyId) {
        return;
    }

    window.location.href = `./${routeName}/?policyId=${policyId}`;
}

paymentBtn.addEventListener("click", () => goTo("payment"));
historyBtn.addEventListener("click", () => goTo("history"));
renewalBtn.addEventListener("click", () => goTo("renewal"));

policyIdInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
        goTo("payment");
    }
});

