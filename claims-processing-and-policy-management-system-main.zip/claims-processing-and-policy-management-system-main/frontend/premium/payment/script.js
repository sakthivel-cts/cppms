const API_BASE = localStorage.getItem("premiumApiBase") || "http://localhost:8082";

const policyIdInput = document.getElementById("policyId");
const amountInput = document.getElementById("amount");
const modeSelect = document.getElementById("mode");
const payButton = document.getElementById("payButton");
const renewalButton = document.getElementById("renewalButton");
const historyButton = document.getElementById("historyButton");
const statusMessage = document.getElementById("statusMessage");
const paymentSummary = document.getElementById("paymentSummary");

const params = new URLSearchParams(window.location.search);
const policyIdParam = params.get("policyId");
const amountParam = params.get("amount");

if (policyIdParam) {
    policyIdInput.value = policyIdParam;
}

if (amountParam) {
    amountInput.value = amountParam;
}

async function loadPremiumAmount() {
    const policyId = Number(policyIdInput.value);
    if (!policyId || amountInput.value) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/premium/renew/${policyId}`);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || "Unable to load premium details.");
        }

        amountInput.value = data.premiumAmount ?? "";
    } catch (error) {
        statusMessage.textContent = error.message;
    }
}

function getPolicyId() {
    const value = Number(policyIdInput.value);
    if (!value || value <= 0) {
        throw new Error("Please enter a valid policy ID.");
    }
    return value;
}

function showSummary(payment) {
    paymentSummary.classList.remove("hidden");
    paymentSummary.innerHTML = `
        <div><strong>Payment ID:</strong> ${payment.paymentId ?? "-"}</div>
        <div><strong>Policy ID:</strong> ${payment.policyId}</div>
        <div><strong>Amount Paid:</strong> ${payment.amountPaid}</div>
        <div><strong>Payment Mode:</strong> ${payment.paymentMode}</div>
        <div><strong>Status:</strong> ${payment.paymentStatus}</div>
        <div><strong>Payment Date:</strong> ${payment.paymentDate ?? "-"}</div>
    `;
}

function goTo(routeName) {
    try {
        const policyId = getPolicyId();
        window.location.href = `../${routeName}/?policyId=${policyId}`;
    } catch (error) {
        statusMessage.textContent = error.message;
    }
}

payButton.addEventListener("click", async () => {
    paymentSummary.classList.add("hidden");

    try {
        const payload = {
            policyId: getPolicyId(),
            amountPaid: Number(amountInput.value),
            paymentMode: modeSelect.value
        };

        statusMessage.textContent = "Processing payment...";

        const response = await fetch(`${API_BASE}/premium/pay`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || "Unable to process premium payment.");
        }

        if (data.paymentStatus === "RECEIVED") {
            statusMessage.textContent = ` Payment received successfully on ${data.paymentDate}.`;
        } else if (data.paymentStatus === "PENDING") {
            statusMessage.textContent = " Payment recorded as pending. Full premium amount was not received.";
        } else {
            statusMessage.textContent = "Payment failed.";
        }

        showSummary(data);
    } catch (error) {
        statusMessage.textContent = error.message;
    }
});

renewalButton.addEventListener("click", () => goTo("renewal"));
historyButton.addEventListener("click", () => goTo("history"));
policyIdInput.addEventListener("change", loadPremiumAmount);

loadPremiumAmount();

