const API_BASE = localStorage.getItem("premiumApiBase") || "http://localhost:8082";

const policyIdInput = document.getElementById("policyId");
const checkButton = document.getElementById("checkButton");
const payButton = document.getElementById("payButton");
const historyButton = document.getElementById("historyButton");
const message = document.getElementById("message");
const details = document.getElementById("details");

const detailPolicyId = document.getElementById("detailPolicyId");
const detailHolderName = document.getElementById("detailHolderName");
const detailPolicyStatus = document.getElementById("detailPolicyStatus");
const detailExpiryDate = document.getElementById("detailExpiryDate");
const detailPremiumAmount = document.getElementById("detailPremiumAmount");
const detailDaysUntilExpiry = document.getElementById("detailDaysUntilExpiry");
const detailRenewalEligible = document.getElementById("detailRenewalEligible");

const params = new URLSearchParams(window.location.search);
const policyIdParam = params.get("policyId");

if (policyIdParam) {
    policyIdInput.value = policyIdParam;
}

function getPolicyId() {
    const value = Number(policyIdInput.value);
    if (!value || value <= 0) {
        throw new Error("Please enter a valid policy ID.");
    }
    return value;
}

function renderRenewalDetails(data) {
    details.classList.remove("hidden");
    detailPolicyId.textContent = data.policyId ?? "-";
    detailHolderName.textContent = data.policyHolderName ?? "-";
    detailPolicyStatus.textContent = data.policyStatus ?? "-";
    detailExpiryDate.textContent = data.expiryDate ?? "-";
    detailPremiumAmount.textContent = data.premiumAmount ?? "-";
    detailDaysUntilExpiry.textContent = data.daysUntilExpiry ?? "-";
    detailRenewalEligible.textContent = data.renewalEligible ? "Yes" : "No";
}

function buildStatusMessage(data) {
    switch (data.message) {
        case "expired":
            return " Policy has expired. Renewal payment can be attempted.";
        case "grace":
            return " Policy is in grace period. Renewal is recommended now.";
        case "cancelled":
            return " Policy is cancelled and cannot be renewed.";
        case "pending-issuance":
            return " Policy is pending issuance. Premium renewal is not available yet.";
        default:
            return " Policy is active and up to date.";
    }
}

async function checkRenewal() {
    try {
        const policyId = getPolicyId();
        message.textContent = "Loading renewal details...";

        const response = await fetch(`${API_BASE}/premium/renew/${policyId}`);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || "Unable to load renewal details.");
        }

        renderRenewalDetails(data);
        message.textContent = buildStatusMessage(data);
    } catch (error) {
        details.classList.add("hidden");
        message.textContent = error.message;
    }
}

function goTo(routeName) {
    try {
        const policyId = getPolicyId();
        let target = `../${routeName}/?policyId=${policyId}`;

        if (routeName === "payment" && detailPremiumAmount.textContent !== "-") {
            target += `&amount=${encodeURIComponent(detailPremiumAmount.textContent)}`;
        }

        window.location.href = target;
    } catch (error) {
        message.textContent = error.message;
    }
}

checkButton.addEventListener("click", checkRenewal);
payButton.addEventListener("click", () => goTo("payment"));
historyButton.addEventListener("click", () => goTo("history"));

if (policyIdParam) {
    checkRenewal();
}

