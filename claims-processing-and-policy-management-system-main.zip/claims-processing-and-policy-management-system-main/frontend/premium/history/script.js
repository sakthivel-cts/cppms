const API_BASE = localStorage.getItem("premiumApiBase") || "http://localhost:8082";

const policyIdInput = document.getElementById("policyId");
const loadButton = document.getElementById("loadButton");
const paymentButton = document.getElementById("paymentButton");
const renewalButton = document.getElementById("renewalButton");
const message = document.getElementById("message");
const historyBody = document.getElementById("historyBody");

const params = new URLSearchParams(window.location.search);
const policyIdParam = params.get("policyId");

if (policyIdParam) {
    policyIdInput.value = policyIdParam;
}

function getPolicyId() {
    const value = Number(policyIdInput.value);
    if (!value || value <= 0) {
        throw new Error("Please enter a valid policy ID.");
    }
    return value;
}

function renderRows(rows) {
    if (!rows.length) {
        historyBody.innerHTML = `
            <tr>
                <td colspan="5" class="empty">No premium payments recorded for this policy yet.</td>
            </tr>
        `;
        return;
    }

    historyBody.innerHTML = rows.map((payment) => `
        <tr>
            <td>${payment.paymentId ?? "-"}</td>
            <td>${payment.amountPaid ?? "-"}</td>
            <td>${payment.paymentMode ?? "-"}</td>
            <td>${payment.paymentStatus ?? "-"}</td>
            <td>${payment.paymentDate ?? "-"}</td>
        </tr>
    `).join("");
}

async function loadHistory() {
    try {
        const policyId = getPolicyId();
        message.textContent = "Loading premium history...";

        const response = await fetch(`${API_BASE}/premium/history/${policyId}`);
        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || "Unable to load premium history.");
        }

        renderRows(data);
        message.textContent = `Loaded ${data.length} premium payment record(s).`;
    } catch (error) {
        message.textContent = error.message;
        renderRows([]);
    }
}

function goTo(routeName) {
    try {
        const policyId = getPolicyId();
        window.location.href = `../${routeName}/?policyId=${policyId}`;
    } catch (error) {
        message.textContent = error.message;
    }
}

loadButton.addEventListener("click", loadHistory);
paymentButton.addEventListener("click", () => goTo("payment"));
renewalButton.addEventListener("click", () => goTo("renewal"));

if (policyIdParam) {
    loadHistory();
}

