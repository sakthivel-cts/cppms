const BACKEND_URL = "http://localhost:8081";
let policyId = null;

// Get ID from URL
function getPolicyId() {
    const params = new URLSearchParams(window.location.search);
    return params.get("id");
}

// Load policy on page load
window.onload = function () {
    policyId = getPolicyId();

    if (!policyId) {
        alert("No policy ID provided");
        return;
    }

    loadPolicy(policyId);
};

//Fetch policy details
function loadPolicy(id) {

    fetch(`${BACKEND_URL}/policies/${id}`)
        .then(res => {
            if (!res.ok) {
                throw new Error("Policy not found");
            }
            return res.json();
        })
        .then(data => {

            document.getElementById("name").value = data.policyHolderName;
            document.getElementById("age").value = data.age;
            document.getElementById("type").value = data.policyType;
            document.getElementById("sum").value = data.sumInsured;
            document.getElementById("premium").value = data.premiumAmount || "";

            document.getElementById("status").value = data.policyStatus;

        })
        .catch(err => {
            console.error(err);
            alert("Failed to load policy");
        });
}

//Calculate premium
function calculatePremium() {

    // Call backend to calculate premium
    fetch(`${BACKEND_URL}/policies/calculate/${policyId}`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(res => {
        if (!res.ok) {
            return res.text().then(text => {
                throw new Error(text || "Calculate failed");
            });
        }
        return res.json();
    })
    .then(data => {
        // Update premium field with value from backend
        document.getElementById("premium").value = data.premiumAmount || 0;
        
        document.getElementById("message").innerText =
            "Premium calculated: " + data.premiumAmount;
        document.getElementById("message").style.color = "green";
    })
    .catch(err => {
        console.error("Calculate error:", err);
        document.getElementById("message").innerText =
            "Failed to calculate: " + err.message;
        document.getElementById("message").style.color = "red";
    });
}

// Update policy status
function updatePolicy() {

    const status = document.getElementById("status").value;
    const premium = parseFloat(document.getElementById("premium").value);

    // Validate premium is calculated
    if (!premium || premium <= 0) {
        document.getElementById("message").innerText =
            "Please calculate premium first";
        document.getElementById("message").style.color = "red";
        return;
    }

    // Call backend to update status with query parameter
    fetch(`${BACKEND_URL}/policies/status/${policyId}?status=${status}`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(res => {
        if (!res.ok) {
            return res.text().then(text => {
                throw new Error(text || "Update failed");
            });
        }
        return res.json();
    })
    .then(data => {

        document.getElementById("message").innerText =
            "Policy updated successfully";

        document.getElementById("message").style.color = "green";
    })
    .catch(err => {
        console.error("Update error:", err);
        document.getElementById("message").innerText =
            "Failed: " + err.message;
        document.getElementById("message").style.color = "red";
    });
}