
const BACKEND_URL = "http://localhost:8081";

document.addEventListener("DOMContentLoaded", () => {

    const form = document.getElementById("policyForm");

    form.addEventListener("submit", async (e) => {
        e.preventDefault();

        // Get values
        const name = document.getElementById("name").value.trim();
        const age = parseInt(document.getElementById("age").value);
        const type = document.getElementById("type").value;
        const sum = parseFloat(document.getElementById("sum").value);

        // Validation
        if (!name || !age || !type || !sum) {
            alert("Please fill all fields");
            return;
        }

        // API data
        const data = {
            policyHolderName: name,
            age: age,
            policyType: type,
            sumInsured: sum
        };

        try {
            const response = await fetch(`${BACKEND_URL}/policies/create`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(data)
            });

            if (!response.ok) {
                const errText = await response.text();
                throw new Error(errText || "Failed to create policy");
            }

            const result = await response.json();

            // Success message
            document.getElementById("message").innerText =
                "Policy Created! ID: " + result.policyId;

            document.getElementById("message").style.color = "green";

            form.reset();

            window.location.href = "./policy-list/index.html";


        } catch (error) {
            console.error(error);

            document.getElementById("message").innerText =
                " Error: " + error.message;

            document.getElementById("message").style.color = "red";
        }
    });

});
