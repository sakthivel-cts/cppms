const BACKEND_URL = "http://localhost:8081";

// Load policies on page load
window.onload = function () {
    loadPolicies();
};

//Fetch all policies
function loadPolicies() {

    fetch(`${BACKEND_URL}/policies/all`)
        .then(res => res.json())
        .then(data => {

            const table = document.getElementById("policyTable");
            table.innerHTML = "";

            // Loop through policies
            data.forEach(policy => {

                const row = `
                    <tr>
                        <td>${policy.policyId}</td>
                        <td>${policy.policyHolderName}</td>
                        <td>${policy.policyType}</td>
                        <td>${policy.sumInsured}</td>
                        <td>${policy.policyStatus}</td>
                        <td>
                            <button class="btn btn-primary btn-sm"
                                onclick="viewPolicy(${policy.policyId})">
                                View
                            </button>
                        </td>
                    </tr>
                `;

                table.innerHTML += row;
            });

        })
        .catch(err => {
            console.error(err);
            alert(" Failed to load policies");
        });
}

// Redirect to view page
function viewPolicy(id) {
    window.location.href = "../view-list/index.html?id=" + id;
}
