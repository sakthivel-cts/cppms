const BACKEND_URL = "http://localhost:8082";

// Dummy user data matching User entity (id, name, username, password, role)
const dummyUser = {
    id: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    name: "Sakthivel D",
    username: "sakthivel_d",
    role: "ADMIN"
};

const populateProfile = (user) => {
    const initials = user.name
        ? user.name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2)
        : "--";

    document.getElementById("avatar-initials").textContent = initials;
    document.getElementById("profile-fullname").textContent = user.name;
    document.getElementById("profile-role-badge").textContent = formatRole(user.role);

    document.getElementById("info-fullname").textContent = user.name;
    document.getElementById("info-username").textContent = user.username;
    document.getElementById("info-role").textContent = formatRole(user.role);
    // document.getElementById("info-userid").textContent = user.id;
};

const formatRole = (role) => {
    if (!role) return "N/A";
    return role.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase());
};

document.getElementById("btn-change-password")?.addEventListener("click", () => {
    window.location.href = "../auth/reset-password.html";
});

// Load dummy data on page ready
populateProfile(dummyUser);
