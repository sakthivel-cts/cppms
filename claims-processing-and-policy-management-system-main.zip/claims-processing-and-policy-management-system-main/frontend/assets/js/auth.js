const forgotForm = document.getElementById("forgotForm");
if (forgotForm) {
    forgotForm.addEventListener("submit", e => {
        e.preventDefault();
        document.getElementById("responseMsg").innerHTML =
            "<span class='text-success'>If account exists, reset link has been sent</span>";
    });
}

const resetForm = document.getElementById("resetForm");
if (resetForm) {
    resetForm.addEventListener("submit", e => {
        e.preventDefault();
        document.getElementById("resetMsg").innerHTML =
            "<span class='text-success'>Password reset successful</span>";
    });
}