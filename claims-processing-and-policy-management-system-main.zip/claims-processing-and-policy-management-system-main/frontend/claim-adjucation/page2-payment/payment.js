const BASE = "http://localhost:8081/adjudication";

function toggleMode() {

    let mode = document.getElementById("mode").value;

    let upi = document.getElementById("upiSection");
    let bank = document.getElementById("bankSection");

    if (mode === "UPI") {

        upi.style.display = "block";
        bank.style.display = "none";

    } else if (mode === "BANK_TRANSFER") {

        bank.style.display = "block";
        upi.style.display = "none";
    }

    document.getElementById("payBtn").disabled = false;
}

function pay() {

    let mode = document.getElementById("mode").value;

    let params = new URLSearchParams(window.location.search);
    let claimId = params.get("claimId");

    fetch(`${BASE}/settlement/${claimId}?payoutMode=${mode}`, {
        method: "POST"
    })
    .then(res => res.json())
    .then(() => {

        alert("Payment Successful! Claim Settled");
    });
}