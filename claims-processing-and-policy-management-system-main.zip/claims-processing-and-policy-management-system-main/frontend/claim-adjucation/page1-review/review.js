const BASE = "http://localhost:8081/adjudication";

function loadReview() {

    let id = document.getElementById("claimId").value;

    fetch(`${BASE}/review/${id}`)
    .then(res => res.text())
    .then(data => {

        document.getElementById("verifyResult").innerText = data;
        document.getElementById("eligibilityResult").innerText = data;
        document.getElementById("docResult").innerText = data;
    });
}

function openDoc() {

    let id = document.getElementById("claimId").value;
    window.open(`${BASE}/open-document/${id}`, "_blank");
}

function approve() {

    let id = document.getElementById("claimId").value;

    fetch(`${BASE}/approve/${id}`, { method: "PUT" })
    .then(() => {

        alert("Claim Approved");

        window.location.href = `../page2-payment/payment.html?claimId=${id}`;
    });
}

function reject() {

    let id = document.getElementById("claimId").value;

    fetch(`${BASE}/reject/${id}`, { method: "PUT" })
    .then(() => {

        alert("Claim Rejected");
    });
}