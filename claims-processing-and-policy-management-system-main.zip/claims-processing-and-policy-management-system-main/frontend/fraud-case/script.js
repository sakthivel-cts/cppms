const BACKEND_URL = "http://localhost:8082";

import { getAuthHeaders } from "../scripts/script.js";

let fraudList_tbody = document.getElementById("fraudList-tbody");

window.redirectToFraudCaseDetailsPage = (caseId) => {
  try {
    console.log("Redirecting with caseId:", caseId);

    window.location.href = `details/index.html?caseId=${caseId}`;
  } catch (error) {
    console.error("Redirect failed:", error);
  }
};

const editFraudList = (fraudList) => {
  fraudList_tbody.innerHTML = "";

  fraudList.forEach((fraud) => {
    const scoreClass =
      fraud.fraudScore >= 70
        ? "high"
        : fraud.fraudScore >= 40
          ? "medium"
          : "low";
    let fraudComponent = `
            <tr>
                <td>${fraud.caseId}</td>
                <td>${fraud.claim?.claimId || "N/A"}</td>
                <td>
                    <span class="fraud-score ${scoreClass}">${fraud.fraudScore}%</span>
                </td>
                <td>${fraud.investigator?.name || "Not Assigned"}</td>
                <td class="status pending">${fraud.caseStatus}</td>
                <td style="text-align: center;">
                    <div class="action-buttons">
                        <button class="btn-action btn-view"
                            onclick="redirectToFraudCaseDetailsPage('${fraud.caseId}')">
                            View
                        </button>
                        <button class="btn-action btn-investigate">
                            Investigate
                        </button>
                    </div>
                </td>
            </tr>
            `;

    fraudList_tbody.innerHTML += fraudComponent;
  });
};

const getFraudList = async () => {
  const auth = getAuthHeaders();

  try {
    const res = await fetch(BACKEND_URL + "/fraud-case/list", {
      method: "GET",
      headers: {
        Authorization: auth,
        "Content-Type": "application/json",
      },
    }).then((response) => response.json());

    console.log(res);

    if (!res.success) {
      console.log(res.message);
      fraudList_tbody.innerHTML = `
            <tr>
              <td colspan="6" style="text-align: center; padding: var(--space-xl);">
                  <span style="color: var(--color-text-muted);">${res.message}</span>
              </td>
            </tr>
  `;
      return;
    }

    editFraudList(res.data);
  } catch (error) {
    console.log(error);
  }
};

getFraudList();
