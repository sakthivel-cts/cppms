import { redirectTo404ErrorPage, getAuthHeaders } from "../../scripts/script.js";

const BACKEND_URL = "http://localhost:8082";

const params = new URLSearchParams(window.location.search);
const caseId = params.get("caseId");

let fraud_investigator_list;

let selectedInvestigator = {
  id : "",
  username : ""
};

window.onload = () => {
  if (caseId === "" || caseId === null || !caseId) {
    window.location.href = "/auth/404.html";
  }

  document.getElementById("case-id").value = caseId;

  loadFraudCaseDetails(caseId);
  loadInvestigators();
};

window.selectInvestigator = (userId, username, element) => {
    selectedInvestigator.id = userId;
    selectedInvestigator.username = username;
    document.querySelectorAll(".investigator-card").forEach(card => {
        card.classList.remove("selected");
    });
    element.classList.add("selected");
};

window.assignInvestigator = async () => {
  const auth = getAuthHeaders();
  try {
    const response = await fetch(BACKEND_URL + `/fraud-case/assign?username=${selectedInvestigator.username}&caseId=${caseId}`,{
      method : "GET",
      headers : {
        "Authorization" : auth,
        "Content-Type" : "application/json"
      }
    })
    .then(res => res.json());

    if (!response.success) throw new Error(response.message);

    window.location.href = "/fraud-case";
  } catch (err) {
    console.log(err.message);
    redirectTo404ErrorPage();
  }
};

const loadFraudCaseDetails = async () => {
  const auth = getAuthHeaders();
  try {
    const response = await fetch(BACKEND_URL + `/fraud-case/get/${caseId}`, {
      method: "GET",
      headers : {
        "Authorization" : auth,
        "Content-Type" : "application/json"
      }
    })
      .then((response) => response.json())
      .catch((err) => {
        redirectTo404ErrorPage();
        console.log(err);
      });

    if (!response.success) {
      console.log(response.message);
      throw new Error(response.message);
    }
  } catch (error) {
    redirectTo404ErrorPage();
    console.log(error);
  }
};

const loadInvestigators = async () => {
  const auth = getAuthHeaders();
  try {
    const response = await fetch(`${BACKEND_URL}/user/list`, {
      method : "GET",
      headers : {
        "Authorization" : auth,
        "Contentt-Type" : "application/json"
      }
    });
    const res = await response.json();

    const list = document.getElementById("investigator-list");
    list.innerHTML = "";

    fraud_investigator_list = res.data.filter(
      (user) => user.role === "FRAUD_INVESTIGATOR"
    );

    if (!fraud_investigator_list || fraud_investigator_list.length === 0) {
      list.innerHTML = `
        <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
          <p style="color: #7f8c8d; font-size: 16px;">No Fraud Investigators Available</p>
        </div>
      `;
      return;
    }

    fraud_investigator_list.forEach((user) => {
      const firstLetter = user.name.charAt(0).toUpperCase();

      const card = `
        <div class="investigator-card"
            onclick="selectInvestigator('${user.id}', '${user.username}', this)">
            <div class="avatar">${firstLetter}</div>
            <p class="investigator-name">${user.name}</p>
            <p class="investigator-username">@${user.username}</p>
        </div>
      `;

      list.innerHTML += card;
    });

  } catch (err) {
    console.error("Fetch failed:", err);
  }
};

const searchForParticularUserByUsername = (username) => {

  if (username.trim() === "") {
    loadInvestigators();
    return;
  }

  const list = document.getElementById("investigator-list");

  if (!fraud_investigator_list || fraud_investigator_list.length === 0) {
    console.log("No Fraud Investigator Found!!!");
    return;
  }

  list.innerHTML = "";

  const filteredUsers = fraud_investigator_list.filter((user) =>
    user.username.toLowerCase().includes(username.toLowerCase()) ||
    user.name.toLowerCase().includes(username.toLowerCase())
  );

  if (filteredUsers.length === 0) {
    list.innerHTML = `
      <div style="grid-column: 1/-1; text-align: center; padding: 40px;">
        <p style="color: #7f8c8d; font-size: 16px;">No matching investigator found</p>
      </div>
    `;
    return;
  }

  filteredUsers.forEach((user) => {
    const firstLetter = user.name.charAt(0).toUpperCase();

    const card = `
      <div class="investigator-card"
          onclick="selectInvestigator('${user.id}', '${user.username}', this)">
          <div class="avatar">${firstLetter}</div>
          <p class="investigator-name">${user.name}</p>
          <p class="investigator-username">@${user.username}</p>
      </div>
    `;

    list.innerHTML += card;
  });
};


window.goBack = () => {
  try {
    window.history.back();
  } catch (err) {
    console.log(err);
  }
};

document.getElementById("search-user").addEventListener("input", (e) => {
  searchForParticularUserByUsername(e.target.value);
});