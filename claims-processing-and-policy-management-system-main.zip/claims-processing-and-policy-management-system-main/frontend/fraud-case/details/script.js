import { redirectTo404ErrorPage, getAuthHeaders, changeEnumToStringForRole } from "../../scripts/script.js";

const BACKEND_URL = "http://localhost:8082";

let case_id;
let case_score;
let case_summary;
let case_status;

let claim_id;
let ploicy_id;
let claim_amount;
let claim_type;
let incident_date;
let claim_status;

let investigator_details;
let investigator_name;
let investigator_username;
let investigator_role;

let actions_buttons;

const params = new URLSearchParams(window.location.search);
const caseId = params.get("caseId");

window.onload = () => {
  case_id = document.getElementById("case-id");
  case_score = document.getElementById("case-score");
  case_summary = document.getElementById("case-summary");
  case_status = document.getElementById("case-status");

  claim_id = document.getElementById("claim-id");
  ploicy_id = document.getElementById("policy-id");
  claim_amount = document.getElementById("claim-amount");
  claim_type = document.getElementById("claim-type");
  incident_date = document.getElementById("incident-date");
  claim_status = document.getElementById("claim-status");

  investigator_details = document.getElementById("investigator-details");
  investigator_name = document.getElementById("investigator-name");
  investigator_username = document.getElementById("investigator-username");
  investigator_role = document.getElementById("investigator-role");

  actions_buttons = document.getElementById("actions-buttons");

  if (caseId === "" || caseId === null) {
    window.location.href = "/auth/404.html";
  }
};

const redirectToAssignInvestigatorPage = (case_id) => {
  try {
    window.location.href = `../assign-investigator/index.html?caseId=${case_id}`;
  } catch (err) {
    console.log(err.message);
  }
};

const loadFraudCaseDetails = async (caseId) => {
  const auth = getAuthHeaders();
  try {
    const response = await fetch(BACKEND_URL + `/fraud-case/get/${caseId}`, {
      method: "GET",
      headers: {
        "Authorization" : auth,
        "Content-Type" : "application/json"
      }
    })
      .then((response) => response.json())
      .catch((err) => {
        redirectTo404ErrorPage();
        console.log(err);
      });

    if (!response.success) {
      console.log(response.message);
      throw new Error(response.message);
    }

    console.log(response.data);

    case_id.innerText = response.data.caseId;
    case_status.innerText = response.data.caseStatus;
    case_score.innerText = response.data.fraudScore;
    case_summary.innerText = response.data.findingSummary;

    claim_id.innerText = response.data.claim.claimId;
    ploicy_id.innerText = response.data.claim.policyId;
    claim_amount.innerText = response.data.claim.claimAmount;
    claim_type.innerText = response.data.claim.claimType;
    incident_date.innerText = response.data.claim.incidentDate;
    claim_status.innerText = response.data.claim.claimStatus;

    if (response.data.investigator === null) {
      const investigator_details_component = `
                <div class="col-md-12 text-center">
                    <p>Investigator Not Assigned Yet</p>
                    <div>
                        <button class="btn btn-primary assign-btn" data-id="${response.data.caseId}">
                            Assign Investigator
                        </button>
                    </div>
                </div>
            `;

      setTimeout(() => {
        document.querySelectorAll(".assign-btn").forEach((btn) => {
          btn.addEventListener("click", (e) => {
            const caseId = e.target.dataset.id;
            redirectToAssignInvestigatorPage(caseId);
          });
        });
      }, 0);

      investigator_details.innerHTML = investigator_details_component;
      actions_buttons.innerHTML = "";
    } else {
      investigator_name.innerText = response.data.investigator.name;
      investigator_username.innerText = response.data.investigator.username;
      investigator_role.innerText = changeEnumToStringForRole(response.data.investigator.role);
    }
  } catch (error) {
    redirectTo404ErrorPage();
    console.log(error);
  }
};

loadFraudCaseDetails(caseId);
